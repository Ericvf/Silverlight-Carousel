﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.ComponentModel;

namespace SilverlightCarousel
{
    /// <summary>
    /// Represents a Canvas control with children rendered in a Carousel layout
    /// </summary>
    public class CarouselCanvas : Canvas
    {
        #region Classes
        /// <summary>
        /// Event arguments
        /// </summary>
        public class RoutedEventArgs : EventArgs
        {
            public UIElement OriginalSource { get; set; }
        }

        #endregion

        #region Delegates and Events
        /// <summary> 
        /// Internal RoutedEventHandler 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void RoutedEventHandler(object sender, RoutedEventArgs e);

        /// <summary>
        /// Selecting item 
        /// </summary>
        public event RoutedEventHandler SelectingItem;

        /// <summary>
        /// Selected item
        /// </summary>
        public event RoutedEventHandler SelectedItem;

        /// <summary>
        /// Deselected item
        /// </summary>
        public event RoutedEventHandler DeselectedItem;

        #endregion

        #region Consts
        /// <summary>
        /// Represents a full circle in radians
        /// </summary>
        private const double fullCircle = Math.PI * 2;

        /// <summary>
        /// Represents a quarter of a circle in radians
        /// </summary>
        private const double quarterCircle = fullCircle / 4;

        #endregion

        #region Private fields
        /// <summary>
        /// Represents the angle of the segments of each child
        /// </summary>
        private double segmentCircle;

        /// <summary>
        /// Represents the target offset for all segments
        /// </summary>
        private double segmentOffsetTarget;

        /// <summary>
        /// Represents the current offset for all segments
        /// </summary>
        private double segmentOffset;

        /// <summary>
        /// Represents the delta value for all segments
        /// </summary>
        private double segmentDelta;

        /// <summary>
        /// A dictionary that contains a unique ID for each child
        /// </summary>
        private Dictionary<int, UIElement> childrenIndex = new Dictionary<int, UIElement>();

        /// <summary>
        /// Main animation for shifting the canvas
        /// </summary>
        private Storyboard storyBoard = new Storyboard();

        /// <summary>
        /// The currently selected item
        /// </summary>
        private int currentItem;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the horizontal radius of the carousel orientation
        /// </summary>
        public double RadiusX { get; set; }

        /// <summary>
        /// Gets or sets the vertical radius of the carousel orientation
        /// </summary>
        public double RadiusY { get; set; }

        /// <summary>
        /// Gets or sets the delay in the transition
        /// </summary>
        public double TransitionDelay { get; set; }

        /// <summary>
        /// Gets or sets the decelleration 
        /// </summary>
        public double Decelleration { get; set; }

        /// <summary>
        /// Gets or sets the elasticity
        /// </summary>
        public double Elasticity { get; set; }

        /// <summary>
        /// Gets or sets the minimum amount of opacity
        /// </summary>
        public double MinOpacity { get; set; }

        /// <summary>
        /// Gets or sets the minimum scale of each object
        /// </summary>
        public double MinScale { get; set; }

        #endregion

        #region Initialization
        /// <summary>
        /// Initializes the canvas
        /// </summary>
        public CarouselCanvas()
            : base()
        {
            // Create a loaded event
            this.Loaded += new System.Windows.RoutedEventHandler(CarouselCanvas_Loaded);
        }

        /// <summary>
        /// Loads the canvas
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CarouselCanvas_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            // Create an completed event handler for the storyboard
            this.storyBoard.Completed += new EventHandler(storyBoard_Completed);

            // Loop through all the children and create ID's for them
            int totalChildren;
            if ((totalChildren = this.Children.Count) > 0)
            {
                // Add the child with its ID
                for (int i = 0; i < totalChildren; i++)
                {
                    this.childrenIndex.Add(i, this.Children[i]);

                    // Make sure the rendertransform origin is in the center of the control so it scales nicely
                    this.Children[i].RenderTransformOrigin = new Point(0.5f, 0.5f);
                }

                // Update the size of segment
                this.segmentCircle = fullCircle / totalChildren;
            }

            // Handle null properties
            if (this.RadiusX == 0)
                this.RadiusX = this.Width / 2;

            if (this.RadiusY == 0)
                this.RadiusY = this.Height / 2;

            // Transform all the children
            this.TransformChildren();
        }

        #endregion

        /// <summary>
        /// Transforms the children elements
        /// </summary>
        private void TransformChildren()
        {
            // Find the number of items
            int childrenCount = this.childrenIndex.Count;

            // Loop through all the children
            foreach (var dictionaryItem in this.childrenIndex)
            {
                // Find the ID and element
                int id = dictionaryItem.Key;
                var childElement = dictionaryItem.Value;

                
                // Transform the child
                this.TransformChild((double)id / childrenCount, childElement);
            }
        }

        /// <summary>
        /// Transforms the child element
        /// </summary>
        /// <param name="childElement"></param>
        private void TransformChild(double positionDelta, UIElement childElement)
        {
            // Find the center of the canvas
            var targetX = this.Width / 2;
            var targetY = this.Height / 2;

            // Subtract the width of the child
            targetX -= (double)childElement.GetValue(Canvas.WidthProperty) / 2;
            targetY -= (double)childElement.GetValue(Canvas.HeightProperty) / 2;
            
            // Calculate the full angle for this child
            var angle = fullCircle * positionDelta + quarterCircle - (segmentOffset * segmentCircle);

            // Add the ellipse offset
            targetX += Math.Cos(angle) * this.RadiusX;
            targetY += Math.Sin(angle) * this.RadiusY;

            // Measure the scale
            var scale = this.MinScale + Math.Sin(angle) / 4;
            var opacity = 1 + this.MinOpacity + Math.Sin(angle);

            // 
            TransformGroup elementTransforms = new TransformGroup();

            // Set the transform on the child
            elementTransforms.Children.Add(new ScaleTransform()
            {
                ScaleX = scale,
                ScaleY = scale
            });

            // Set the transform on the child
            elementTransforms.Children.Add(new TranslateTransform()
            {
                X = targetX,
                Y = targetY,
            });

            // Apply transforms
            childElement.RenderTransform = elementTransforms;

            // Set the opacity
            childElement.Opacity = opacity;

            // Set the zIndex
            childElement.SetValue(Canvas.ZIndexProperty, (int)(scale * 1000));
        }

        /// <summary>
        /// Selects the item specified and shows it first in the carousel orientation
        /// </summary>
        /// <param name="selectedControl"></param>
        public void SelectItem(UIElement uIElement, bool animate)
        {
            // Select the dictionary element that contains the ID using LINQ
            int id = (from index in this.childrenIndex
                      where index.Value.Equals(uIElement)
                      select index.Key).Single();

            // Call the selecting event
            if (this.SelectingItem != null)
                this.SelectingItem(this, new RoutedEventArgs()
                {
                    OriginalSource = uIElement
                });

            // Call the selecting event
            if (this.DeselectedItem != null)
                this.DeselectedItem(this, new RoutedEventArgs()
                {
                    OriginalSource = this.childrenIndex[this.currentItem]
                });

            // Check if we have a delay 
            if (this.TransitionDelay > 0 && animate)
            {
                // Set the target
                this.segmentOffsetTarget = id;

                // Calculate the distance from each path
                var distanceClockwise = this.segmentOffset - id;
                var distanceCounterwise = this.childrenIndex.Count - Math.Abs(distanceClockwise);

                // If the clockwise distance is faster, add it to the offset
                if (Math.Abs(distanceClockwise) < Math.Abs(distanceCounterwise))
                    segmentOffset = segmentOffsetTarget + distanceClockwise;

                // If the counterclockwise distance is faster
                if (Math.Abs(distanceCounterwise) < Math.Abs(distanceClockwise))
                {
                    // If we are switching orientation, subtract 
                    if (segmentOffset > segmentOffsetTarget)
                        distanceCounterwise *= -1;

                    // Add it to the offset
                    segmentOffset = segmentOffsetTarget + distanceCounterwise;
                }

                // Start the animation so it can smoothly go to the target
                this.storyBoard.Begin();
            }
            else // Set the offset directly without an animation
            {
                // Update the segmentOffset
                this.segmentOffset = id;

                // Update the transformations
                this.TransformChildren();
            }

            // Set the current item
            this.currentItem = id;
        }

        /// <summary>
        /// Selects the next item in the carousel
        /// </summary>
        public void Next()
        {
            // Find next id
            int next = this.currentItem + 1;

            // Check if the id exists
            if (next >= this.childrenIndex.Count)
                next = 0;

            // Select the item
            this.SelectItem(this.childrenIndex[next], true);
        }

        /// <summary>
        /// Selects the previous item in the carousel
        /// </summary>
        public void Previous()
        {
            // Find next id
            int previous = this.currentItem - 1;

            // Check if the id exists
            if (previous < 0)
                previous = this.childrenIndex.Count - 1;

            // Select the item
            this.SelectItem(this.childrenIndex[previous], true);
        }

        /// <summary>
        /// Updates the UI after this event is called
        /// </summary>
        public void UpdateAfterEvent()
        {
            this.TransformChildren();
        }

        #region Animation

        /// <summary>
        /// Handles the animations for the control
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void storyBoard_Completed(object sender, EventArgs e)
        {
            // Measure the differnce
            double difference = this.segmentOffsetTarget - this.segmentOffset;

            // Check if the difference is greater than 1
            if (Math.Abs(difference) > 0.001)
            {
                if (this.Elasticity > 0 && this.Decelleration > 0)
                {
                    // Calculate the delta
                    segmentDelta = difference * this.Decelleration + segmentDelta * this.Elasticity;

                    // Add a portion of the difference to the offset
                    this.segmentOffset += segmentDelta / this.TransitionDelay;
                }
                else
                {
                    this.segmentOffset += difference / this.TransitionDelay;
                }

                // Start the animation again next frame since were not finished
                this.storyBoard.Begin();
            }
            else
            {
                // Call the selecting event
                if (this.SelectedItem != null)
                    this.SelectedItem(this, new RoutedEventArgs()
                    {
                        OriginalSource = this.childrenIndex[this.currentItem]
                    });

                // If the difference is smaller than 0.1, just round it off
                this.segmentOffset = this.segmentOffsetTarget;
            }

            // Update the children
            this.TransformChildren();
        }

        #endregion
    }
}
