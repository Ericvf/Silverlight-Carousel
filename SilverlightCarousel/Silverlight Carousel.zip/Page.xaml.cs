﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace SilverlightCarousel
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();

            this.carousel1.SelectingItem += new CarouselCanvas.RoutedEventHandler(carousel1_SelectingItem);
            this.carousel1.SelectedItem += new CarouselCanvas.RoutedEventHandler(carousel1_SelectedItem);
            this.carousel1.DeselectedItem += new CarouselCanvas.RoutedEventHandler(carousel1_DeselectedItem);
        }

        void carousel1_DeselectedItem(object sender, CarouselCanvas.RoutedEventArgs e)
        {
            Button elm = e.OriginalSource as Button;

            string msg = "Deselected item " + elm.Content;

            this.AddToList(msg);
        }

        void carousel1_SelectedItem(object sender, CarouselCanvas.RoutedEventArgs e)
        {
            Button elm = e.OriginalSource as Button;

            string msg = "Selected item " + elm.Content;

            this.AddToList(msg);
        }

        void carousel1_SelectingItem(object sender, CarouselCanvas.RoutedEventArgs e)
        {
            Button elm = e.OriginalSource as Button;

            string msg = "Selecting item " + elm.Content;

            this.AddToList(msg);
        }

        private void AddToList(string message)
        {
            Debug.WriteLine(message);

            this.listBox.Items.Insert(0, message);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button clicked = sender as Button;

            if (clicked != null)
            {
                this.carousel1.SelectItem(clicked, true);
            }
        }

        private void Prev_Click(object sender, RoutedEventArgs e)
        {
            this.carousel1.Previous();
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            this.carousel1.Next();
        }

        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (this.carousel1 == null)
                return;

            this.carousel1.RadiusX = e.NewValue;
            this.carousel1.UpdateAfterEvent();
        }

        private void slider2_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (this.carousel1 == null)
                return;

            this.carousel1.RadiusY = e.NewValue;
            this.carousel1.UpdateAfterEvent();
        }

        private void slider3_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (this.carousel1 == null)
                return;

            this.carousel1.MinOpacity = e.NewValue;
            this.carousel1.UpdateAfterEvent();
        }

        private void slider4_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (this.carousel1 == null)
                return;

            this.carousel1.TransitionDelay = e.NewValue;
            this.carousel1.UpdateAfterEvent();
        }

        private void slider5_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (this.carousel1 == null)
                return;

            this.carousel1.Elasticity = e.NewValue;
            this.carousel1.UpdateAfterEvent();
        }

        private void slider6_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (this.carousel1 == null)
                return;

            this.carousel1.Decelleration = e.NewValue;
            this.carousel1.UpdateAfterEvent();
        }

        private void slider7_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (this.carousel1 == null)
                return;

            this.carousel1.MinScale = e.NewValue;
            this.carousel1.UpdateAfterEvent();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            this.slider1.Value = 200;
            this.slider2.Value = 50;
            this.slider3.Value = 0.10;
            this.slider7.Value = 0.80;
            this.slider4.Value = 20;
            this.slider5.Value = 0;
            this.slider6.Value = 0;

        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            this.slider1.Value = 200;
            this.slider2.Value = 50;
            this.slider3.Value = 0.10;
            this.slider7.Value = 0.80;
            this.slider4.Value = 0;
            this.slider5.Value = 0.8;
            this.slider6.Value = 0.2;
        }

        private void RadioButton_Checked_2(object sender, RoutedEventArgs e)
        {
            this.slider1.Value = 180;
            this.slider2.Value = 0;
            this.slider3.Value = 0.20;
            this.slider7.Value = 0.80;
            this.slider4.Value = 0;
            this.slider5.Value = 0.95;
            this.slider6.Value = 0.05;
        }
    }
}
